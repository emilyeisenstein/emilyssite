$("document").ready(function() {
  $('.slideshow-image').click(function()
  {
  console.log("clicked!")
  $('.slideshow-image').addClass('slideshow-zoom')
})
})
